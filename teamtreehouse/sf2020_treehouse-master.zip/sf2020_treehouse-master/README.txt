  
URL to access website easily:  https://rhea2801.github.io/sf2020_treehouse

this is a fully responsive front-end replica of teamtreehouse.com, done as a project to hone my css skills
